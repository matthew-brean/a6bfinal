/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2016-11-25
* Created for: ICS4U
* Assignment: #6
* Main stub for Yahtzee game
*
*******************************************************************************/
package a6b;
public class Yahtzee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameEngine yahtzee = new GameEngine();
		yahtzee.newGame();
	}

}