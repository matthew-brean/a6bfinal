/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2016-11-25
* Created for: ICS4U
* Assignment: #6
* Dice properties & rolling methods
*
*******************************************************************************/
package a6b;
import java.util.Random;

public class Roll {
	private int[] _diceVals = new int[5];
	private boolean[] _restricted = new boolean[5];
	private int _timesRolled = 0;
	
	public void rollDice(){
		Random rand = new Random();
		for (int counter = 0; counter < 5; counter++){ //change i to counter  later
			if (!this._restricted[counter]){
				this._diceVals[counter] = rand.nextInt(6) + 1;
			}
		}
		this._timesRolled++;
	}
	public void restrictDie(int die){
		this._restricted[die-1] = true;
	}
	
	public void unrestrictDie(int die){
		this._restricted[die-1] = false;
	}

	public int[] getDice(){
		return this._diceVals;
	}
	
	public void printDice(){
		
		System.out.println("Die A. " + this._diceVals[0]);
		System.out.println("Die B. " + this._diceVals[1]);
		System.out.println("Die C. " + this._diceVals[2]);
		System.out.println("Die D. " + this._diceVals[3]);
		System.out.println("Die E. " + this._diceVals[4]);
	}
	
	public int getTimesRolled(){
		return this._timesRolled;
	}
	
	public void resetRolls(){
		this._timesRolled = 0;
		for (int counter = 0; counter < 5; counter++){
			
			this._restricted[counter] = false;
		}
	}
}