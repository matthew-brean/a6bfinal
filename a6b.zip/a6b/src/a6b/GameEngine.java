/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2016-11-25
* Created for: ICS4U
* Assignment: #6
* Engine behind application
*
*******************************************************************************/

package a6b;
import java.util.Scanner;

public class GameEngine {
	
	public void newGame(){
		Scanner SCANNER = new Scanner(System.in);
		ScoreSheet ScoreSheet = new ScoreSheet();
		Roll roll = new Roll();
		String userString;
		int userInt;
		
		System.out.println("Type 'play' to play game.");
		
		if (SCANNER.next().equals("play")){
			roll.rollDice();
			
			for (;;){ for (;;){ //double infinite for
				System.out.println("\n\n");
				
				roll.printDice();
				System.out.println("Rolls left: " + (3-roll.getTimesRolled()));
				ScoreSheet.printRounds();
				ScoreSheet.printScores();
				System.out.println("Which action to take?\n1.Roll again\n2.Restrict die\n3.Unrestrict die\n4.Use scoresheet");
				
				if (ScoreSheet.checkYahtzee(roll.getDice())){
					System.out.println("Press any key to continue.");
					userString = SCANNER.next();
					roll.resetRolls();
					roll.rollDice();
					break;
				}
			
				userString = SCANNER.next(); 
				if (userString.equals("1")){
					if (roll.getTimesRolled()!=3)
						roll.rollDice();
					else 
						System.out.println("Rolled 3 times!");
				}
				//restrict
				else if (userString.equals("2")){
					System.out.println("Identify which die to restrict using letter that correlates to die #.");
					if (SCANNER.hasNextInt())
						roll.restrictDie(SCANNER.nextInt());
					else
						System.out.println("Invalid action");
				}
				//unrestrict
				else if(userString.equals("3")){
					System.out.println("Identify which die to unrestrict using letter that correlates to die #.");
					if (SCANNER.hasNextInt())
						roll.unrestrictDie(SCANNER.nextInt());
					else
						System.out.println("Invalid action");
				}
				//scoresheet
					System.out.println("Choose a box to score.");
					if (SCANNER.hasNextInt()){
						userInt = SCANNER.nextInt();
						if ((userInt > 0 && userInt<14)&&(!ScoreSheet.getScoresFilled(userInt))){
							ScoreSheet.score(userInt, roll.getDice());
							System.out.println("Press any key to continue.");
							userString = SCANNER.next();
							roll.resetRolls();
							roll.rollDice();
						}
						else System.out.println("Invalid action");
					}
					else System.out.println("Invalid action");
				}
				
			}
		}
	}
}
